#!/usr/bin/env python3
"""Run after `cap add android`: turns the launcher entry into 10 switchable <activity-alias> icons."""
import re,sys
P='android/app/src/main/AndroidManifest.xml'
s=open(P,encoding='utf-8').read()
# remove the LAUNCHER category from MainActivity (aliases take over)
s=re.sub(r'\s*<category android:name="android.intent.category.LAUNCHER"\s*/>','',s,count=1)
al=''
for c in ['verde','coral','naranja','azul','morado']:
    for m in ['oscuro','claro']:
        v=f'{c}_{m}'
        al+=f'''
        <activity-alias android:name=".Icon_{v}" android:targetActivity=".MainActivity" android:exported="true"
            android:enabled="{'true' if v=='verde_oscuro' else 'false'}" android:icon="@mipmap/ic_icon_{v}" android:roundIcon="@mipmap/ic_icon_{v}" android:label="@string/app_name">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity-alias>'''
s=s.replace('</application>',al+'\n    </application>',1)
open(P,'w',encoding='utf-8').write(s)
print('aliases added')
