package com.sonodial.app;

import android.content.Context;
import android.database.ContentObserver;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Connects the volume bar of Sonodial to the Android MEDIA volume
 * (the same one the phone's volume buttons control).
 *
 * JS side:  Capacitor.registerPlugin('SonodialVolume')
 *   getVolume()          -> { value: 0..1 }
 *   setVolume({value})   -> sets the media volume (0..1)
 *   event 'volumeChange' -> { value: 0..1 } (fires when the hardware buttons change it)
 */
@CapacitorPlugin(name = "SonodialVolume")
public class SonodialVolumePlugin extends Plugin {
    private AudioManager am;
    private ContentObserver observer;

    @Override
    public void load() {
        am = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
        observer = new ContentObserver(new Handler(Looper.getMainLooper())) {
            @Override
            public void onChange(boolean selfChange) {
                JSObject o = new JSObject();
                o.put("value", current());
                notifyListeners("volumeChange", o);
            }
        };
        getContext().getContentResolver()
            .registerContentObserver(Settings.System.CONTENT_URI, true, observer);
    }

    private double current() {
        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        return max == 0 ? 0 : (double) am.getStreamVolume(AudioManager.STREAM_MUSIC) / max;
    }

    @PluginMethod
    public void getVolume(PluginCall call) {
        JSObject o = new JSObject();
        o.put("value", current());
        call.resolve(o);
    }

    @PluginMethod
    public void setVolume(PluginCall call) {
        double v = call.getDouble("value", 0.0);
        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        am.setStreamVolume(AudioManager.STREAM_MUSIC, (int) Math.round(Math.max(0, Math.min(1, v)) * max), 0);
        call.resolve();
    }

    @Override
    protected void handleOnDestroy() {
        if (observer != null) getContext().getContentResolver().unregisterContentObserver(observer);
    }
}
