package com.sonodial.app;

import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/**
 * Saves the exported summary image into the phone's Downloads folder
 * and opens the Android share sheet.
 *
 * JS side:  Capacitor.registerPlugin('SonodialSave')
 *   save({data: base64, filename})  -> saves to Downloads, resolves { uri }
 *   share({data: base64, filename}) -> saves to Downloads, opens the share sheet
 */
@CapacitorPlugin(name = "SonodialSave")
public class SonodialSavePlugin extends Plugin {

    private Uri store(String b64, String name) throws Exception {
        byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, name);
            v.put(MediaStore.Downloads.MIME_TYPE, "image/png");
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri u = getContext().getContentResolver()
                .insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (u == null) throw new Exception("Could not create file");
            try (OutputStream o = getContext().getContentResolver().openOutputStream(u)) {
                o.write(bytes);
            }
            return u;
        }
        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        dir.mkdirs();
        File f = new File(dir, name);
        try (FileOutputStream o = new FileOutputStream(f)) {
            o.write(bytes);
        }
        return Uri.fromFile(f);
    }

    @PluginMethod
    public void save(PluginCall call) {
        try {
            Uri u = store(call.getString("data", ""), call.getString("filename", "summary.png"));
            JSObject o = new JSObject();
            o.put("uri", u.toString());
            call.resolve(o);
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }

    @PluginMethod
    public void share(PluginCall call) {
        try {
            Uri u = store(call.getString("data", ""), call.getString("filename", "summary.png"));
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("image/png");
            i.putExtra(Intent.EXTRA_STREAM, u);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent c = Intent.createChooser(i, null);
            c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(c);
            call.resolve();
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }
}
