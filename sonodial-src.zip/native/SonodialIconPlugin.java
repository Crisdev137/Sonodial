package com.sonodial.app;

import android.content.ComponentName;
import android.content.pm.PackageManager;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Changes the launcher icon by enabling one <activity-alias> (Icon_<variant>)
 * and disabling the others.  JS: Capacitor.registerPlugin('SonodialIcon')
 *   get()            -> { variant: "verde_oscuro" }
 *   set({variant})   -> enables that icon
 */
@CapacitorPlugin(name = "SonodialIcon")
public class SonodialIconPlugin extends Plugin {
    private static final String[] COLORS = {"verde", "coral", "naranja", "azul", "morado"};
    private static final String[] MODES = {"oscuro", "claro"};

    private ComponentName cn(String v) {
        return new ComponentName(getContext().getPackageName(), "com.sonodial.app.Icon_" + v);
    }

    @PluginMethod
    public void get(PluginCall call) {
        PackageManager pm = getContext().getPackageManager();
        String cur = "verde_oscuro";
        for (String c : COLORS) for (String m : MODES) {
            String v = c + "_" + m;
            if (pm.getComponentEnabledSetting(cn(v)) == PackageManager.COMPONENT_ENABLED_STATE_ENABLED) cur = v;
        }
        JSObject o = new JSObject();
        o.put("variant", cur);
        call.resolve(o);
    }

    @PluginMethod
    public void set(PluginCall call) {
        String want = call.getString("variant", "verde_oscuro");
        PackageManager pm = getContext().getPackageManager();
        boolean ok = false;
        for (String c : COLORS) for (String m : MODES) if ((c + "_" + m).equals(want)) ok = true;
        if (!ok) { call.reject("bad variant"); return; }
        try {
            // enable the new one first so the app never has zero launchers
            pm.setComponentEnabledSetting(cn(want), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
            for (String c : COLORS) for (String m : MODES) {
                String v = c + "_" + m;
                if (!v.equals(want))
                    pm.setComponentEnabledSetting(cn(v), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
            }
            call.resolve();
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }
}
