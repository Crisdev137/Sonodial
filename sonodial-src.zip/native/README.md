# Volume bar -> Android media volume

The volume bar in the player already talks to a small bridge (`VB` in index.html):

- In the browser it controls the audio element volume (works in Chrome on Android, not on iPhone).
- In the APK it uses the `SonodialVolume` Capacitor plugin and controls the phone's MEDIA volume.
  The bar also moves when the volume buttons of the phone are pressed.

Files:
- `SonodialVolumePlugin.java` - reads and sets the media volume, notifies the page when it changes.
- `SonodialSavePlugin.java` - saves the exported summary image to the Downloads folder and opens the share sheet.
- `MainActivity.java` - registers the plugin and makes the volume buttons control media volume.
- `../build.yml` - copies these files into the Android project after `npx cap add android`.

Nothing else to configure. Replace `index.html` with the latest `sonodial.html` before building.
