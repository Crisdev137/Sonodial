package com.sonodial.app;

import android.media.AudioManager;
import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(SonodialVolumePlugin.class);
        registerPlugin(SonodialSavePlugin.class);
        registerPlugin(SonodialIconPlugin.class);
        super.onCreate(savedInstanceState);
        // The phone's volume buttons always control the media volume inside the app
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
    }
}
